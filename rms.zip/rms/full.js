/* 
DO NOT REMOVE THIS COPYRIGHT
 Copyright 2020-2024 MagTek, Inc, Paul Deignan.
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), 
 to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

// import * as mt_Utils from "./mt_utils.js";
/* 
DO NOT REMOVE THIS COPYRIGHT
 Copyright 2020-2024 MagTek, Inc, Paul Deignan.
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), 
 to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

function toHexString(byteArray) {
  return Array.prototype.map
    .call(byteArray, function (byte) {
      return ("0" + (byte & 0xff).toString(16)).toUpperCase().slice(-2);
    })
    .join("");
}

function AsciiToHexPad(AsciiString, length) {
  var hex = (AsciiToHex(AsciiString) + "0".repeat(length * 2)).slice(0, length * 2);
  return hex;
};


function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function makeHex(value, sigDigits) {
  var hex = ("0".repeat(sigDigits) + value.toString(16).toUpperCase()).slice(
    -sigDigits
  );
  return hex;
}
function hexToASCII(hexString) {
  var str = "";
  for (var n = 0; n < hexString.length; n += 2) {
    str += String.fromCharCode(parseInt(hexString.substr(n, 2), 16));
  }
  return str;
}

function AsciiToHex(str) {
  var arr1 = [];
  for (var n = 0, l = str.length; n < l; n++) {
    var hex = Number(str.charCodeAt(n)).toString(16).toUpperCase();
    arr1.push(hex);
  }
  return arr1.join('');
};

function hexToDecIPv4(hexString) {
  var str = "";
  for (var n = 0; n < hexString.length; n += 2) {
    str += parseInt(hexString.substr(n, 2), 16).toString();
    if (n < (hexString.length - 2)) str += ".";
  }
  return str;
}


function hexToASCIInulltoNewLine(hexString) {
  var str = "";
  for (var n = 0; n < hexString.length; n += 2) {
    if (parseInt(hexString.substr(n, 2), 16) == 0) {
      str += '\n';
    } else {
      str += String.fromCharCode(parseInt(hexString.substr(n, 2), 16));
    }
  }
  return str;
}

function hexToASCIIRemoveNull(hexString) {
  var str = "";
  for (var n = 0; n < hexString.length; n += 2) {
    if (parseInt(hexString.substr(n, 2), 16) != 0) {
      str += String.fromCharCode(parseInt(hexString.substr(n, 2), 16));
    }
  }
  return str;
};


function tlvParser(hexdata) {
  var data = hexToBytes(hexdata);
  const dataLength = data.length;
  const moreTagBytesFlag1 = 0x1f;
  const moreTagBytesFlag2 = 0x80;
  const constructedFlag = 0x20;
  const moreLengthFlag = 0x80;
  const oneByteLengthMask = 0x7f;

  let result = [];
  let iTLV = 0;
  let iTag;
  let bTag = true;
  let byteValue;
  let lengthValue;
  let tagBytes = null;
  let TagBuffer = [];

  while (iTLV < dataLength) {
    byteValue = data[iTLV];

    if (bTag) {
      iTag = 0;
      let bMoreTagBytes = true;

      if (byteValue === 0) {
        //First byte of tag cannot be zero.
        break;
      }

      while (bMoreTagBytes && iTLV < dataLength) {
        byteValue = data[iTLV];
        iTLV++;
        TagBuffer[iTag] = byteValue;
        bMoreTagBytes =
          iTag === 0
            ? (byteValue & moreTagBytesFlag1) == moreTagBytesFlag1
            : (byteValue & moreTagBytesFlag2) == moreTagBytesFlag2;
        iTag++;
      }
      tagBytes = toHexString(TagBuffer.slice(0, iTag));
      bTag = false;
    } else {
      lengthValue = 0;
      if ((byteValue & moreLengthFlag) == moreLengthFlag) {
        let nLengthBytes = byteValue & oneByteLengthMask;
        iTLV++;
        let iLen = 0;
        while (iLen < nLengthBytes && iTLV < dataLength) {
          byteValue = data[iTLV];
          iTLV++;
          lengthValue = ((lengthValue & 0x000000ff) << 8) + byteValue;
          iLen++;
        }
      } else {
        lengthValue = byteValue & oneByteLengthMask;
        iTLV++;
      }

      if (tagBytes) {
        let tagByte = TagBuffer[0];
        let endIndex =
          iTLV + lengthValue > dataLength ? dataLength : iTLV + lengthValue;
        let len = endIndex - iTLV;
        let valueBytes =
          len > 0 ? toHexString(data.slice(iTLV, iTLV + len)) : "";
        result.push({
          tag: tagBytes,
          tagLength: !lengthValue ? valueBytes.length + 1 / 2 : lengthValue,
          tagValue: valueBytes,
        });
        if (!((tagByte & constructedFlag) == constructedFlag)) {
          iTLV += lengthValue;
        }
      }
      bTag = true;
    }
  }
  return result;
}

function getTagValue(tagName, defaultTagValue, tlvData, asASCII) {
  try {
    var TLVS = tlvParser(tlvData);
    var currtlv = TLVS.find((tlv) => tlv.tag === tagName);
    if (currtlv == undefined) return defaultTagValue;
    {
      if (asASCII == true) {
        return hexToASCIIRemoveNull(currtlv.tagValue);
      }
      else {
        return currtlv.tagValue;
      }
    }
  }
  catch (error) {
    return defaultTagValue;
  }

}

function removeSpaces(str) {
  return str.replace(/\s+/g, "");
}

function hexToBytes(hex) {
  let bytes = [];
  for (let i = 0; i < hex.length; i += 2)
    bytes.push(parseInt(hex.substring(i, i + 2), 16));
  return bytes;
}

function debugLog(data) {
  // console.log(`DebugLog: ${data}`);
}

function getDefaultValue(key, defaultValue) {
  var keyVal = localStorage.getItem(key);
  if (keyVal == null) keyVal = defaultValue;
  return keyVal;
}

function saveDefaultValue(key, value) {
  localStorage.setItem(key, value);
}

function makeid(length) {
  let result = '';
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const charactersLength = characters.length;
  let counter = 0;
  while (counter < length) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
    counter += 1;
  }
  return result;
}

function filterString(inputString) {
  const filteredString = inputString.replace(/[^0-9A-Za-z]/g, '');
  return filteredString;
};



Array.prototype.zeroFill = function (len) {
  for (var i = this.length; i < len; i++) {
    this[i] = 0;
  }
  return this;
};


var mt_Utils = { toHexString, AsciiToHexPad, wait, makeHex, hexToASCII, AsciiToHex, hexToDecIPv4, hexToASCIInulltoNewLine, tlvParser, getTagValue, removeSpaces, hexToBytes, debugLog, getDefaultValue, saveDefaultValue, makeid, filterString }

// import * as mt_MMS from "./mt_mms.js";
/* 
DO NOT REMOVE THIS COPYRIGHT
 Copyright 2020-2024 MagTek, Inc, Paul Deignan.
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), 
 to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

/* 
DO NOT REMOVE THIS COPYRIGHT
 Copyright 2020-2024 MagTek, Inc, Paul Deignan.
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), 
 to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
// Define the event emitter module
const EventEmitter = (() => {
  let events = {};

  // Function to subscribe to events
  const on = (eventName, listener) => {
    if (!events[eventName]) {
      events[eventName] = [];
    }
    events[eventName].push(listener);
  };

  // Function to emit events
  const emit = (eventName, data) => {
    if (events[eventName]) {
      events[eventName].forEach((listener) => {
        listener(data);
      });
    }
  };

  // Function to unsubscribe from events
  const off = (eventName, listener) => {
    if (events[eventName]) {
      events[eventName] = events[eventName].filter((l) => l !== listener);
    }
  };

  return {
    on,
    emit,
    off,
  };
})();

// Expose EventEmitter globally so it can be used in the webpage
window.EventEmitter = EventEmitter;

var LogMMStoConsole = false;
var LogMMStoEvent = false;
var wasOpened = false;

let mtDeviceType = "";

//let device_response = null;
let data_buffer_response = [];

function EmitObject(e_obj) {
  EventEmitter.emit(e_obj.Name, e_obj);
}

async function sendCommand(cmdToSend) {
  let cmdResp = "";
  window.device_response = null;
  try {
    if (window._device == null) {
      EmitObject({
        Name: "OnError",
        Source: "SendCommand",
        Data: "Device is null",
      });
      return 0;
    }
    if (!window._device.opened) {
      EmitObject({
        Name: "OnError",
        Source: "SendCommand",
        Data: "Device is not open",
      });
      return 0;
    }
    cmdResp = await sendMMSCommand(mt_Utils.removeSpaces(cmdToSend));
    return cmdResp;
  } catch (error) {
    EmitObject({ Name: "OnError", Source: "SendCommand", Data: error });
    return error;
  }
}


async function sendMMSCommand(cmdToSend) {
  let commands = buildCmdsArray(
    cmdToSend,
    window._device.collections[0].outputReports[0].items[0].reportCount
  );
  for (let index = 0; index < commands.length; index++) {
    await window._device.sendReport(0, new Uint8Array(commands[index]));
  }

  Response = await waitForDeviceResponse();
  return Response;
};

function waitForDeviceResponse() {
  function waitFor(result) {
    if (result) {
      return result;
    }
    return new Promise((resolve) => setTimeout(resolve, 50))
      .then(() => Promise.resolve(window.device_response))
      .then((res) => waitFor(res));
  }
  return waitFor();
}

async function GetDeviceSN() {
  let resp = await sendCommand("AA0081040100D101841AD10181072B06010401F609850102890AE208E106E104E102C100");
  let str = resp.TLVData.substring(24);
  let tag89 = mt_Utils.getTagValue("89", "", str, false);
  let data = mt_Utils.getTagValue("C1", "", tag89, false);
  return data.substring(0, 7);
}

async function GetDeviceFWID() {
  let resp = await sendCommand("AA0081040102D101841AD10181072B06010401F609850102890AE108E206E204E202C200");
  let str = resp.TLVData.substring(24);
  let tag89 = mt_Utils.getTagValue("89", "", str, false);
  let data = mt_Utils.getTagValue("C2", "", tag89, true);
  return data;
}

function parseMMSPacket(data) {
  let subdata = [];
  switch (data[0]) {
    case 0x00:
      subdata = parseSinglePacket(data);
      EmitObject({
        Name: "OnMMSMessage",
        Data: mt_Utils.toHexString(subdata)
      });
      ParseMMSMessage(subdata);
      break;
    case 0x01:
      parseHeadPacket(data);
      break;
    case 0x02:
      parseMiddlePacket(data);
      break;
    case 0x03:
      subdata = parseTailPacket(data);
      EmitObject({
        Name: "OnMMSMessage",
        Data: mt_Utils.toHexString(subdata)
      });
      ParseMMSMessage(subdata);

      break;
    case 0x04:
      parseCancelPacket(data);
      break;
    default:
      EmitObject({
        Name: "OnError",
        Source: "ParseMMSPacketError",
        Data: data,
      });
  }
}
function ParseMMSMessage(Msg) {
  const MMSMessage = {
    MsgHeader: mt_Utils.makeHex(Msg[0], 2),
    MsgVersion: mt_Utils.makeHex(Msg[1], 2),
    MsgType: mt_Utils.makeHex(Msg[4], 2),
    RefNum: mt_Utils.makeHex(Msg[5], 2),
    RespID: mt_Utils.makeHex((Msg[6] << 8) | Msg[7], 4),
    TLVData: mt_Utils.toHexString(Msg.slice(8, Msg.length)),
    HexString: mt_Utils.toHexString(Msg)
  };

  if (LogMMStoConsole) {
    mt_Utils.debugLog("++++++++++++++++++++++++++++++++++++++++++++++++++++");
    mt_Utils.debugLog("Header: " + MMSMessage.MsgHeader);
    mt_Utils.debugLog("Version: " + MMSMessage.MsgVersion);
    mt_Utils.debugLog("MsgType: " + MMSMessage.MsgType);
    mt_Utils.debugLog("RefNum: " + MMSMessage.RefNum);
    mt_Utils.debugLog("RespID: " + MMSMessage.RespID);
    mt_Utils.debugLog("TLVData: " + MMSMessage.TLVData);
    mt_Utils.debugLog("HexString: " + MMSMessage.HexString);
    mt_Utils.debugLog("++++++++++++++++++++++++++++++++++++++++++++++++++++");
  }
  if (LogMMStoEvent) {
    EmitObject({
      Name: "OnDebug",
      Source: "MMSMessage",
      Data: JSON.stringify(MMSMessage),
    });
  }
  switch (MMSMessage.MsgType) {
    case "01":
      parseRequestFromHost(MMSMessage);
      break;
    case "02":
      parseResponseFromHost(MMSMessage);
      break;
    case "03":
      parseNotificationFromHost(MMSMessage);
      break;
    case "04":
      parseFileFromHost(MMSMessage);
      break;
    case "81":
      parseRequestFromDevice(MMSMessage);
      break;
    case "82":
      parseResponseFromDevice(MMSMessage);
      break;
    case "83":
      parseNotificationFromDevice(MMSMessage);
      break;
    case "84":
      parseFileFromDevice(MMSMessage);
      break;
    default:
      EmitObject({ Name: "OnError", Source: "MMSParseError", Data: Msg });
  }
}

function parseManualEntryDetail(Msg) {
  let NotifyDetail = mt_Utils.getTagValue("82", "", Msg.TLVData, false);
  let Detail = NotifyDetail.substring(2, 8);
  switch (Detail) {
    case "010100": //Manual Card Entry Data Entered
      NotifyDetail = Msg.TLVData;
      EmitObject({ Name: "OnManualDataEntered", Data: NotifyDetail });
      break;
    case "100101":
      console.log(Msg.TLVData);
      break;
    case "080202": //Manual Card Entry ARQC
      NotifyDetail = Msg.TLVData;
      EmitObject({
        Name: "OnARQCData",
        Source: "Manual",
        Data: NotifyDetail.substring(12),
      });
      break;
    case "080302": //Manual Card Entry BatchData
      NotifyDetail = Msg.TLVData;
      EmitObject({
        Name: "OnBatchData",
        Source: "Manual",
        Data: NotifyDetail.substring(12),
      });
      break;
    default:
      NotifyDetail = Msg.TLVData;
      EmitObject({
        Name: "OnError",
        Source: "ManualError",
        Data: NotifyDetail,
      });
      break;
  }
}
function parseMSRDetail(Msg) {
  let NotifyDetail = mt_Utils.getTagValue("82", "", Msg.TLVData, false);
  let Detail = NotifyDetail.substring(2, 8);
  switch (Detail) {
    case "010100": //Swiped
      NotifyDetail = Msg.TLVData;
      EmitObject({ Name: "OnMSRCardSwiped", Data: "Transaction in progress" });
      break;
    case "010200": //Inserted
      NotifyDetail = Msg.TLVData;
      EmitObject({
        Name: "OnMSRCardInserted",
        Data: "Transaction in progress",
      });
      break;
    case "010300": //Removed
      NotifyDetail = Msg.TLVData;
      EmitObject({ Name: "OnMSRCardRemoved", Data: "Transaction in progress" });
      break;
    case "010400": //Detected
      NotifyDetail = Msg.TLVData;
      EmitObject({ Name: "OnMSRCardDetected", Data: NotifyDetail });
      break;
    case "080202": //ARQC
      NotifyDetail = mt_Utils.getTagValue("84", "", Msg.TLVData, false);
      EmitObject({
        Name: "OnARQCData",
        Source: "MSR",
        Data: NotifyDetail.substring(12),
      });
      break;
    case "080302": //BATCH
      NotifyDetail = mt_Utils.getTagValue("84", "", Msg.TLVData, false);
      EmitObject({
        Name: "OnBatchData",
        Source: "MSR",
        Data: NotifyDetail.substring(12),
      });
      break;
    default:
      NotifyDetail = Msg.TLVData;
      EmitObject({ Name: "OnError", Source: "MSRError", Data: NotifyDetail });
      break;
  }
}
function parseContactDetail(Msg) {
  let NotifyDetail = mt_Utils.getTagValue("82", "", Msg.TLVData, false);
  let Detail = NotifyDetail.substring(2, 8);
  switch (Detail) {
    case "010200": //Inserted
      NotifyDetail = Msg.TLVData;
      //EmitObject({Name:"OnContactCardInserted",Data:NotifyDetail});
      EmitObject({
        Name: "OnContactCardInserted",
        Data: "Transaction in progress",
      });
      break;
    case "010300": //Removed
      NotifyDetail = Msg.TLVData;
      //EmitObject({Name:"OnContactCardRemoved",Data:NotifyDetail});
      EmitObject({
        Name: "OnContactCardRemoved",
        Data: "Transaction in progress",
      });
      break;
    case "010400": //Detected
      NotifyDetail = Msg.TLVData;
      EmitObject({ Name: "OnContactCardDetected", Data: NotifyDetail });
      break;
    case "020601": //EMV Contact PINPad Error
      NotifyDetail = Msg.TLVData;
      EmitObject({ Name: "OnContactPINPadError", Data: NotifyDetail });
      break;
    case "020602": //EMV Contact PIN Block Encryption Error
      NotifyDetail = Msg.TLVData;
      EmitObject({ Name: "OnContactPINBlockError", Data: NotifyDetail });
      break;
    case "080202": //ARQC
      NotifyDetail = mt_Utils.getTagValue("84", "", Msg.TLVData, false);
      EmitObject({
        Name: "OnARQCData",
        Source: "EMV",
        Data: NotifyDetail.substring(12),
      });
      break;
    case "080302": //BATCH
      NotifyDetail = mt_Utils.getTagValue("84", "", Msg.TLVData, false);
      EmitObject({
        Name: "OnBatchData",
        Source: "EMV",
        Data: NotifyDetail.substring(12),
      });
      break;
    default:
      NotifyDetail = Msg.TLVData;
      EmitObject({
        Name: "OnError",
        Source: "ContactError",
        Data: NotifyDetail,
      });
      break;
  }
}

function parseContactlessDetail(Msg) {
  let NotifyDetail = mt_Utils.getTagValue("82", "", Msg.TLVData, false);
  let Detail = NotifyDetail.substring(2, 8);
  switch (Detail) {
    case "010300": //Removed
      NotifyDetail = Msg.TLVData;
      //EmitObject({Name:"OnContactlessCardRemoved",Data:NotifyDetail});
      EmitObject({
        Name: "OnContactlessCardRemoved",
        Data: "Transaction in progress",
      });
      break;
    case "010400": //EMV Detected
      NotifyDetail = Msg.TLVData;
      //EmitObject({Name:"OnContactlessCardDetected",Data:NotifyDetail});
      EmitObject({
        Name: "OnContactlessCardDetected",
        Data: "Transaction in progress",
      });
      break;
    case "010401": //Mifare Ultralight Detected
      NotifyDetail = Msg.TLVData;
      EmitObject({
        Name: "OnContactlessMifareUltralightCardDetected",
        Data: NotifyDetail,
      });
      break;
    case "010402": //Mifare Classic 1K
      NotifyDetail = Msg.TLVData;
      EmitObject({
        Name: "OnContactlessMifare1KCardDetected",
        Data: NotifyDetail,
      });
      break;
    case "010403": //Mifare Classic 4K
      NotifyDetail = Msg.TLVData;
      EmitObject({
        Name: "OnContactlessMifare4KCardDetected",
        Data: NotifyDetail,
      });
      break;
    case "010500": //Collision
      NotifyDetail = Msg.TLVData;
      EmitObject({ Name: "OnContactlessCardCollision", Data: NotifyDetail });
      break;
    case "011002": //VAS Error
      NotifyDetail = Msg.TLVData;
      EmitObject({ Name: "OnContactlessVASError", Data: NotifyDetail });
      break;
    case "020601": //PINPad Error
      NotifyDetail = Msg.TLVData;
      EmitObject({ Name: "OnContactlessPINPadError", Data: NotifyDetail });
      break;
    case "020602": //PIN Block Error
      NotifyDetail = Msg.TLVData;
      EmitObject({ Name: "OnContactlessPINBlockError", Data: NotifyDetail });
      break;
    case "080202": //ARQC
      NotifyDetail = mt_Utils.getTagValue("84", "", Msg.TLVData, false);
      EmitObject({
        Name: "OnARQCData",
        Source: "NFC",
        Data: NotifyDetail.substring(12),
      });
      break;
    case "080302": //BATCH
      NotifyDetail = mt_Utils.getTagValue("84", "", Msg.TLVData, false);
      EmitObject({
        Name: "OnBatchData",
        Source: "NFC",
        Data: NotifyDetail.substring(12),
      });
      break;
    case "080402": //NFC UID
      NotifyDetail = mt_Utils.getTagValue("84", "", Msg.TLVData, false);
      EmitObject({
        Name: "OnContactlessNFCUID",
        Data: NotifyDetail.substring(18),
      });
      break;
    default:
      NotifyDetail = Msg.TLVData;
      EmitObject({
        Name: "OnError",
        Source: "ContactlessError",
        Data: NotifyDetail,
      });
      break;
  }
}

function parseBarcodeDetail(Msg) {
  let NotifyDetail = mt_Utils.getTagValue("82", "", Msg.TLVData, false);
  let Detail = NotifyDetail.substring(2, 8);
  switch (Detail) {
    case "010100": //Barcode Read
      NotifyDetail = Msg.TLVData;
      EmitObject({ Name: "OnBarcodeRead", Data: NotifyDetail });
      break;
    case "080002": //Barcode Update
      NotifyDetail = Msg.TLVData;
      EmitObject({ Name: "OnBarcodeUpdate", Data: NotifyDetail });
      break;
    default:
      NotifyDetail = Msg.TLVData;
      EmitObject({
        Name: "OnError",
        Source: "BarcodeError",
        Data: NotifyDetail,
      });
      break;
  }
}

function parseNotificationFromDevice(Msg) {
  try {
    let NotifyDetail = mt_Utils.getTagValue("82", "", Msg.TLVData, false);
    switch (Msg.RespID) {
      case "0101":
        let technology = NotifyDetail.substring(0, 2);
        switch (technology) {
          case "00":
            console.log(`Transaction started by Device:  ${Msg.HexString}`);
          case "07": //Manual Entry
            parseManualEntryDetail(Msg);
            break;
          case "08": //MSR
            parseMSRDetail(Msg);
            break;
          case "10": //EMV
            parseContactDetail(Msg);
            break;
          case "20": //EMV Contactless
            parseContactlessDetail(Msg);
            break;
          case "30": //Barcode
            parseBarcodeDetail(Msg);
            break;
          default:
            console.log(` Unknown Tech ${Msg.HexString}`);
            EmitObject({
              Name: "OnError",
              Source: "UnknownTechnology",
              Data: Msg,
            });
            break;
        }
        break;
      case "0103":
        NotifyDetail = Msg.TLVData;
        EmitObject({ Name: "OnTransactionHostAction", Data: NotifyDetail });
        break;
      case "0105":
        NotifyDetail = Msg.TLVData;
        EmitObject({ Name: "OnTransactionComplete", Data: NotifyDetail });
        break;
      case "0201":
        NotifyDetail = Msg.TLVData;
        EmitObject({ Name: "OnBankingNotification", Data: Msg.TLVData });
        break;
      case "0205":
        NotifyDetail = Msg.TLVData;
        let data = mt_Utils.getTagValue("F5", "", Msg.TLVData.substring(24), false);
        let PBF = mt_Utils.getTagValue("DF71", "", data, false);
        let EPB = mt_Utils.getTagValue("99", "", data, false);
        let KSN = mt_Utils.getTagValue("DFDF41", "", data, false);
        let EncType = mt_Utils.getTagValue("DFDF42", "", data, false);




        EmitObject({ Name: "OnPINComplete", Data: { PBF: PBF, EPB: EPB, KSN: KSN, EncType: EncType, TLV: Msg.TLVData } });
        break;
      case "0905":
        NotifyDetail = Msg.TLVData;
        EmitObject({ Name: "OnFirmwareUpdateSuccessful", Data: NotifyDetail });
        break;
      case "0906":
        NotifyDetail = Msg.TLVData;
        EmitObject({ Name: "OnFirmwareUpdateFailed", Data: NotifyDetail });
        break;
      case "0907":
        NotifyDetail = Msg.TLVData;
        EmitObject({ Name: "OnFirmwareUptoDate", Data: NotifyDetail });
        break;
      case "1001":
        let category = NotifyDetail.substring(0, 2);
        switch (category) {
          case "00": //Power Reset
            parsePowerEventDetail(Msg);
            break;
          case "01": //User Event
            parseUserEventDetail(Msg);
            break;
          case "02":

          case "03": //Key Mgmt
            parseKeyEventDetail(Msg);
            break;
          default:
            break;
        }
        break;
      case "1801":
        NotifyDetail = Msg.TLVData;
        EmitObject({ Name: "OnUIInformationUpdate", Data: NotifyDetail });
        break;
      case "1803":
        NotifyDetail = Msg.TLVData;
        let Message = mt_Utils.hexToASCII(NotifyDetail.substring(44));
        EmitObject({ Name: "OnUIDisplayMessage", Data: Message });
        break;
      case "1805":
        NotifyDetail = Msg.TLVData;
        EmitObject({ Name: "OnUIHostActionComplete", Data: NotifyDetail });
        break;
      default:
        NotifyDetail = mt_Utils.toHexString(Msg.TLVData);
        EmitObject({
          Name: "OnError",
          Source: "Unknown Notification",
          Data: toHexString(Msg),
        });
        break;
    }
  } catch (error) {
    EmitObject({
      Name: "OnError",
      Source: "NotificationError",
      Data: JSON.stringify(Msg) + error.Message
    });
  }
}

function parsePowerEventDetail(Msg) {
  let NotifyDetail = mt_Utils.getTagValue("82", "", Msg.TLVData, false);
  let Detail = NotifyDetail.substring(2, 6);
  switch (Detail) {
    case "0000": //Reset Occured
      EmitObject({ Name: "OnPowerEvent", Data: "Reset Occured" });
      break;
    case "0100": //Reset Soon
      EmitObject({ Name: "OnPowerEvent", Data: "Reset Soon" });
      break;
    case "0200": //Low Battery
      EmitObject({ Name: "OnPowerEvent", Data: "Low Battery" });
      break;
    case "0201": //Low Battery
      EmitObject({ Name: "OnPowerEvent", Data: "Low Battery" });
      break;
    case "0300": //Low Battery
      EmitObject({ Name: "OnPowerEvent", Data: "Reset" });
      break;
  }
}

function parseUserEventDetail(Msg) {
  let NotifyDetail = mt_Utils.getTagValue("82", "", Msg.TLVData, false);
  let reasonValue = NotifyDetail.substring(2, 4);
  let xPos;
  let yPos;
  switch (reasonValue) {
    case "00": //Contactless Card Detected
      EmitObject({ Name: "OnContactlessCardDetected", Data: "Idle" });
      break;
    case "01": //Contactless Card Removed
      EmitObject({ Name: "OnContactlessCardRemoved", Data: "Idle" });
      break;
    case "02": //Card Seated in Slot
      EmitObject({ Name: "OnContactCardInserted", Data: "Idle" });
      break;
    case "03": //Card Unseated from Slot
      EmitObject({ Name: "OnContactCardRemoved", Data: "Idle" });
      break;
    case "04": //Card Swiped
      EmitObject({ Name: "OnMSRSwipeDetected", Data: "Idle" });
      break;
    case "05": //Touch Sensor Press On Display
      xPos = Number(`0x${Msg.TLVData.substring(24, 28)}`);
      yPos = Number(`0x${Msg.TLVData.substring(28, 32)}`);
      EmitObject({ Name: "OnTouchDown", Data: { Xpos: xPos, Ypos: yPos } });
      break;
    case "06": //Touch Sensor Release On Display
      xPos = Number(`0x${Msg.TLVData.substring(24, 28)}`);
      yPos = Number(`0x${Msg.TLVData.substring(28, 32)}`);
      EmitObject({ Name: "OnTouchUp", Data: { Xpos: xPos, Ypos: yPos } });
      break;
    case "07": //Barcode Detected
      NotifyDetail = mt_Utils.getTagValue("84", "", Msg.TLVData, false);
      EmitObject({
        Name: "OnBarcodeDetected",
        Data: NotifyDetail.substring(12),
      });
      break;
    default:
      NotifyDetail = Msg.TLVData;
      EmitObject({ Name: "OnUserEvent", Data: NotifyDetail });
      break;
  }
}
function parseKeyEventDetail(Msg) {
  let NotifyDetail = mt_Utils.getTagValue("82", "", Msg.TLVData, false);
  EmitObject({ Name: "OnKeyEvent", Data: NotifyDetail });
}

function parseNotificationFromHost(Msg) {
  let NotifyDetail = mt_Utils.getTagValue("82", "", Msg.TLVData, false);
  EmitObject({ Name: "OnNotificationFromHost", Data: NotifyDetail });
}
function parseRequestFromDevice(Msg) {
  let NotifyDetail = mt_Utils.getTagValue("82", "", Msg.TLVData, false);
  EmitObject({ Name: "OnRequestFromDevice", Data: NotifyDetail });
}
function parseResponseFromDevice(Msg) {
  let NotifyDetail = Msg.TLVData;
  window.device_response = Msg;
  EmitObject({ Name: "OnDeviceResponse", Data: Msg });
}
function parseRequestFromHost(Msg) {
  let NotifyDetail = mt_Utils.getTagValue("82", "", Msg.TLVData, false);
  EmitObject({ Name: "OnRequestFromHost", Data: NotifyDetail });
}
function parseResponseFromHost(Msg) {
  let NotifyDetail = mt_Utils.getTagValue("82", "", Msg.TLVData, false);
  EmitObject({ Name: "OnHostResponse", Data: NotifyDetail });
}

function parseFileFromDevice(Msg) {
  //let NotifyDetail = mt_Utils.getTagValue("82", "", Msg.TLVData, false);
  EmitObject({ Name: "OnFileFromDevice", Data: Msg });
}
function parseFileFromHost(Msg) {
  //let NotifyDetail = mt_Utils.getTagValue("82", "", Msg.TLVData, false);
  EmitObject({ Name: "OnFileFromHost", Data: Msg });
}


function parseSinglePacket(packet) {
  //Entire message is in 1 packet no buufering required
  let respnseLen = packet[1];
  return packet.slice(2, respnseLen + 2);
}

function parseHeadPacket(packet) {
  //message is in more than 1 packet and this is the first
  data_buffer_response.length = 0; //Clear the buffer
  data_buffer_response.push(...packet.slice(5)); //Append this to the buffer
  return null;
}

function parseMiddlePacket(packet) {
  //message is in more than 1 packet and this is a middle packet
  data_buffer_response.push(...packet.slice(3)); //Append this to the buffer
  return null;
}
function parseTailPacket(packet) {
  //message is in more than 1 packet and this is the last packet
  let respnseLen = packet[1];
  data_buffer_response.push(...packet.slice(2, respnseLen + 2)); //Append this to the buffer
  return data_buffer_response;
}
function parseCancelPacket(packet) {
  //message is a cancel multi packet
  data_buffer_response.length = 0; //clear the buffer
  return null;
}

function buildCmdsArray(commandstring, reportLen) {
  const usbEndpointID = "00";
  let MaxMsgDataLen = reportLen - 2;
  let FirstPacketDataLen = reportLen - 5;
  let MiddlePacketDataLen = reportLen - 3;

  let i = 0;
  let SliceSize = 0;
  let RemainingData = commandstring;
  let RemainingLength = 0;

  let packetType = "";
  let packetNumber = "";
  let msgLength = "";
  let DataSlice;

  let cmdArray = [];
  if (commandstring.length > MaxMsgDataLen * 2) {
    //Process multiple packets
    //Process first packet
    packetType = "01";
    msgLength = mt_Utils.makeHex(RemainingData.length / 2, 8);
    SliceSize = FirstPacketDataLen * 2;
    DataSlice = RemainingData.slice(0, SliceSize);
    cmdArray[i] = mt_Utils.hexToBytes(packetType + msgLength + DataSlice);
    RemainingData = RemainingData.slice(SliceSize);
    RemainingLength = RemainingData.length;

    while (RemainingLength > 0) {
      i++;
      if (RemainingLength > MaxMsgDataLen * 2) {
        //Process middle packet
        packetType = "02";
        packetNumber = mt_Utils.makeHex(i, 4);
        SliceSize = MiddlePacketDataLen * 2;
        DataSlice = RemainingData.slice(0, SliceSize);
        cmdArray[i] = mt_Utils.hexToBytes(
          packetType + packetNumber + DataSlice
        );
        RemainingData = RemainingData.slice(SliceSize);
        RemainingLength = RemainingData.length;
      } else {
        //Process tail packet
        packetType = "03";
        msgLength = mt_Utils.makeHex(RemainingData.length / 2, 2);
        cmdArray[i] = mt_Utils
          .hexToBytes(packetType + msgLength + RemainingData)
          .zeroFill(reportLen);
        RemainingLength = 0;
      }
    }
  } else {
    //process as single packet format
    packetType = "00";
    msgLength = mt_Utils.makeHex(commandstring.length / 2, 2);
    cmdArray[i] = mt_Utils
      .hexToBytes(packetType + msgLength + commandstring)
      .zeroFill(reportLen);
  }
  return cmdArray;
}



async function openDevice() {
  try {
    let reqDevice;
    let devices = await navigator.hid.getDevices();
    let device = devices.find((d) => d.vendorId === mt_HID.vendorId);

    //if (!device || devices.length > 1) {
    if (!device) {
      let vendorId = mt_HID.vendorId;
      reqDevice = await navigator.hid.requestDevice({ filters: mt_HID.MMSfilters });
      if (reqDevice != null) {
        if (reqDevice.length > 0) {
          device = reqDevice[0];
        }
      }
    }
    if (!device.opened) {
      await device.open();
      device.addEventListener("inputreport", handleInputReport);
    }
    if (device.opened) {
      wasOpened = true;
      let _devinfo = mt_HID.getDeviceInfo(device.productId);
      mtDeviceType = _devinfo.DeviceType;

      switch (mtDeviceType) {
        case "MMS":
          EmitObject({ Name: "OnDeviceOpen", Device: device });
          break;
        default:
          EmitObject({
            Name: "OnError",
            Source: "Bad DeviceType",
            Data: `Use the ${mtDeviceType} Parser`
          });
          break;
      }
    }
    return device;
  } catch (error) {
    EmitObject({
      Name: "OnError",
      Source: "OpenDevice",
      Data: "Error opening device",
    });
  }
};

async function closeDevice() {
  wasOpened = false;
  if (window._device != null) {
    await window._device.close();
    EmitObject({ Name: "OnDeviceClose", Device: window._device });
  }
};

function handleInputReport(e) {
  let dataArray = new Uint8Array(e.data.buffer);
  switch (mtDeviceType) {
    case "CMF":
      EmitObject({
        Name: "OnError",
        Source: "DeviceType",
        Data: "Not Implemented"
      });
      break;
    case "MMS":
      parseMMSPacket(dataArray);
      break;
    case "V5":
      //mt_V5.parseV5Packet(dataArray)
      EmitObject({
        Name: "OnError",
        Source: "DeviceType",
        Data: "Use the V5 Parser"
      });
      break;
    default:
      EmitObject({
        Name: "OnError",
        Source: "DeviceType",
        Data: "Unknown Device Type",
      });
      break;
  }
};

Array.prototype.zeroFill = function (len) {
  for (let i = this.length; i < len; i++) {
    this[i] = 0;
  }
  return this;
};


var mt_MMS = {
  LogMMStoConsole,
  LogMMStoEvent,
  wasOpened,
  sendCommand,
  GetDeviceSN,
  GetDeviceFWID,
  parseMMSPacket,
  ParseMMSMessage,
  buildCmdsArray,
  openDevice,
  closeDevice
}
// import * as mt_HID from "./mt_hid.js";
/* 
DO NOT REMOVE THIS COPYRIGHT
 Copyright 2020-2024 MagTek, Inc, Paul Deignan.
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), 
 to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

let _device;
let _deviceType = "MMS";
let _reportLen = 0;
let vendorId = 0x0801;
let _productId = 0;

async function getDeviceList() {
  let devices = await navigator.hid.getDevices();
  return devices;
}

function getDeviceInfo(pid) {
  //This is required to account for the different report lengths
  //until we can obtain the report length from the USB capabilites
  //we will use this routine to choose lengths for known devices
  //or else we will try the most common length
  let reportLen = 0;
  let deviceType = "unknown";

  switch (pid) {
    case 0x03:
      reportLen = 0x19;
      deviceType = "V5";
      break;
    case 0x19:
      reportLen = 0x3D;
      deviceType = "V5";
      break;
    case 0x20:
      reportLen = 0x40;
      deviceType = "ID5G3";
      break;
    case 0x21:
      reportLen = 0x40;
      deviceType = "ID5G3";
      break;
    case 0x1A:
      reportLen = 0x3D;
      deviceType = "V5";
      break;
    case 0x1C:
      reportLen = 0x3d;
      deviceType = "V5";
      break;
    case 0x1E:
      reportLen = 0x3d;
      deviceType = "V5";
      break;
    case 0x1F:
      reportLen = 0x3d;
      deviceType = "V5";
      break;
    case 0x2020: // DynaFlex
      reportLen = 0x40;
      deviceType = "MMS";
      break;
    case 0x2023: // DynaProx
      reportLen = 0x40;
      deviceType = "MMS";
      break;
    case 0x2024: // DynaProx II Go
      reportLen = 0x40;
      deviceType = "MMS";
      break;
    default:
      reportLen = 0x40;
      deviceType = "V5";
  }
  _reportLen = reportLen;
  return { DeviceType: deviceType, ReportLen: reportLen };
}

const V5filters = [
  {
    vendorId: vendorId,
    productId: 0x03,
  },
  {
    vendorId: vendorId,
    productId: 0x19,
  },
  {
    vendorId: vendorId,
    productId: 0x1A, //mDynamo
  },
  {
    vendorId: vendorId,
    productId: 0x1C, //  tDynamo
  },
  {
    vendorId: vendorId,
    productId: 0x1E, //eDyanmo
  },
  {
    vendorId: vendorId,
    productId: 0x1F, //iDynamo 6
  },
  {
    vendorId: vendorId,
    productId: 0x20, //iDynamo 5G3
  },
  {
    vendorId: vendorId,
    productId: 0x5357, // bootloader
  }
];

const ID5G3filters = [
  {
    vendorId: vendorId,
    productId: 0x20,
  },
  {
    vendorId: vendorId,
    productId: 0x21,
  }
];
const MMSfilters = [
  {
    vendorId: vendorId,
    productId: 0x2020, //DynaFlex
  },
  {
    vendorId: vendorId,
    productId: 0x2021, //DynaFlex Boot 0
  },
  {
    vendorId: vendorId,
    productId: 0x2022, //DynaFlex Boot 1
  },
  {
    vendorId: vendorId,
    productId: 0x2023, //  DynaProx
  },
  {
    vendorId: vendorId,
    productId: 0x2024, //  DynaProx II Go
  }
];

var mt_HID = {
  _device,
  _deviceType,
  _reportLen,
  vendorId,
  _productId,
  getDeviceList,
  getDeviceInfo,
  V5filters,
  ID5G3filters,
  MMSfilters
}

// import * as mt_UI from "./mt_ui.js";
/* 
DO NOT REMOVE THIS COPYRIGHT
 Copyright 2020-2024 MagTek, Inc, Paul Deignan.
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), 
 to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

function updateProgressBar(caption, progress) {
  try {
    const updDeviceContainer = document.getElementById("updDeviceContainer");
    const progressContainer = document.getElementById("progressContainer");
    const progressBar = document.getElementById("progressBar");

    if (progress < 0) {
      updDeviceContainer.style.visibility = "hidden";
      progressContainer.style.visibility = "hidden";
      progressBar.style.visibility = "hidden";
    }
    else {
      updDeviceContainer.style.visibility = "visible";
      progressContainer.style.visibility = "visible";
      progressBar.style.visibility = "visible";
      updDeviceContainer.getElementsByTagName("P")[0].textContent = caption;
      progressBar.ariaValueNow = progress;
      progressBar.style.width = `${progress}%`;
      progressBar.textContent = `${caption} ${progress}%`;
    }
  }
  catch (error) {

  }

};

function LogData(data) {

  try {
    const log = document.getElementById("LogData");
    log.value += data + "\n";
    log.scrollTop = log.scrollHeight;
  } catch (error) {

  }

};

function ClearLog() {
  try {
    const log = document.getElementById("LogData");
    log.value = "";
    updateProgressBar("", -1);
  } catch (error) {

  }
}

function UpdateValue(id, value) {
  try {
    document.getElementById(id).value = value;
  } catch (error) {

  }
}

function GetValue(id) {
  try {
    const element = document.getElementById(id);
    return element.value;
  } catch (error) {
    return null;
  }
}

function FromListToText(event) {
  document.getElementById("sendData").value = event.target.value;
}

function setUSBConnected(value) {
  const item = document.getElementById("USBStatus");
  const label = document.getElementById("lblUSBStatus");
  label.innerText = value;

  switch (value.toLowerCase()) {
    case "opened":
      item.src = "./images/usb-opened.png";
      break;
    case "closed":
      item.src = "./images/usb-closed.png";
      label.value = ""
      break;
    case "connected":
      item.src = "./images/usb-connected.png";
      break;
    case "disconnected":
      item.src = "./images/usb-disconnected.png";
      break;
    case "connect a device":
      item.src = "";
      break;
    case "detecting...":
      item.src = "";
      break;
    default:
      item.src = "./images/usb-disconnected.png";
      break;
  }
};

function DeviceDisplay(value) {
  const item = document.getElementById("DeviceDisplay");
  if (value.length == 0) {
    item.innerText = "WELCOME";
  }
  else {
    item.innerText = value;
  }
};


function AddDeviceLink(type, name, status, url) {
  var bShowOffline = false;

  let isChecked = mt_Utils.getDefaultValue("ShowOffline", "false");
  (isChecked === "true" ? bShowOffline = true : bShowOffline = false);

  //console.log(status);
  const imgOnline = document.createElement('img');
  imgOnline.setAttribute('src', `./images/${status}.png`);
  imgOnline.className = "thumbnail";
  imgOnline.setAttribute('height', '10px');
  imgOnline.setAttribute('width', '10px');

  const img = document.createElement('img');
  img.setAttribute('src', `./images/${type}.png`);
  img.className = "img-fluid img-thumbnail";
  img.setAttribute('height', '60px');
  img.setAttribute('width', '60px');

  const link = document.createElement('a');
  link.id = `dev-${name}`;
  link.href = url;
  link.textContent = name;
  //link.target = "_blank"; // Opens link in a new tab
  link.style.display = "inline-flex";
  link.prepend(imgOnline);
  link.prepend(img);
  if (status == "disconnected") {
    //link.hidden = true;
    link.hidden = !bShowOffline;
  }
  else {
    link.hidden = false;
  }
  const existingLink = document.getElementById(`dev-${name}`);
  if (existingLink == null) {
    document.getElementById('device-links').appendChild(link);
  } else {
    existingLink.replaceWith(link);
  }
}

function UpdateQRCode(qrcode) {
  try {
    document.getElementById(`QRCode`).src = `https://paoli.magensa.net/Test/RenderImage/Home/QRCode?QRData=${qrcode}`;
  } catch (error) {

  }
}

var mt_UI = {
  updateProgressBar,
  LogData,
  ClearLog,
  UpdateValue,
  GetValue,
  FromListToText,
  setUSBConnected,
  DeviceDisplay,
  AddDeviceLink,
  UpdateQRCode
}
// import * as mt_RMS from "./mt_rms_mms.js";
/* 
DO NOT REMOVE THIS COPYRIGHT
 Copyright 2020-2024 MagTek, Inc, Paul Deignan.
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), 
 to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

"use strict";

let _KSN = "";
let _UIK = "";

let _BLEFWID = "";
let _MUT = "";

var _DeviceSN = "";
var _FWID = "";


let _DeviceDetected = false;
let _HasBLEFirmware = false;
let _DeviceConfigList = null;
let _openTimeDelay = 2000;

function setDeviceDetected(bval) {
  _DeviceDetected = bval;
};

/**
 * @param {string} sn
 */
function setDeviceSN(sn) {
  _DeviceSN = sn;
}

/**
 * @param {string} id
 */
function setFWID(id) {
  _FWID = id;
}


function EmitObject(e_obj) {
  EventEmitter.emit(e_obj.Name, e_obj);
};

function LogData(data) {
  EmitObject({ Name: "OnRMSLogData", Data: data });
};

function updateProgress(caption, progress) {
  EmitObject({ Name: "OnRMSProgress", Data: { Caption: caption, Progress: progress } });
};


async function updateDevice() {
  var bStatus = true;
  _DeviceConfigList = null;
  try {
    LogData(`${mt_RMS_API.ProfileName}: Checking for updates...`);
    //bStatus = await getDeviceInfo();
    //bStatus = await updateFirmware("Main");
    //if (_HasBLEFirmware)
    //{
    //  bStatus = await updateFirmware("BLE");
    //}
    bStatus = await updateAllTags();
    //bStatus = await updateAllConfigs();
    LogData(`Device has been updated`);
    updateProgress("", -1);
  } catch (error) {
    LogData(`${error.message}`);
  }
};

async function updateAllTags() {
  LogData(`Checking Tags and CAPKs...`);
  let bStatus = false;

  let updateCommands = [
    "AA0081040108D8218408D825810400000000",
    "AA0081040108D8218408D825810400000100",
    "AA0081040108D8218408D825810400000200",
    "AA0081040108D8218408D825810400000300",
    "AA0081040108D8218408D825810400000400",
    "AA0081040108D8218408D825810400000500",
    "AA0081040108D8218408D825810400000600",
    "AA0081040108D8218408D825810400000700",
    "AA0081040108D8218408D825810400000800",
    "AA0081040108D8218408D825810400000900"
  ];

  for (let index = 0; index < updateCommands.length; index++) {
    bStatus = await updateMMSTags(updateCommands[index]);
  }
  return bStatus;
};

async function getDeviceInfo() {
  //_DeviceSN = await mt_mms.GetDeviceSN(); 
  //_FWID = await mt_mms.GetDeviceFWID();
  return true;
};

async function parseRMSCommands(description, messageArray) {
  for (let index = 0; index < messageArray.length; index++) {
    var progress = parseInt((index / messageArray.length) * 100);
    updateProgress(`Loading ${description}`, progress);
    await parseRMSCommand(messageArray[index]);
  }
  updateProgress(`Done Loading ${description}...`, 100);
};

async function updateMMSTags(command) {
  try {
    let ver = null;
    let strVersion = mt_Utils.getDefaultValue("RMSVersion", "");
    strVersion.length > 0 ? ver = parseInt(strVersion) : ver = null;


    let cmdResp = await mt_mms.sendCommand(command);
    if (cmdResp.HexString.length > 16) {
      let req = {
        Authentication: null,
        ProfileName: mt_RMS_API.ProfileName,
        ConfigurationName: null,
        Version: ver,
        UIK: null,
        TerminalConfiguration: cmdResp.HexString,
        BillingLabel: mt_Utils.getDefaultValue("RMSBillingLabel", "WEB Demo Test"),
        InterfaceType: mt_Utils.getDefaultValue("RMSInterface", "USB"),
        DownloadPayload: true,
        FirmwareID: _FWID,
        DeviceSerialNumber: _DeviceSN
      };

      var tagsResp = await mt_RMS_API.GetTags(req);
    }

    switch (tagsResp.ResultCode) {
      case -2:
        break;
      case 0:
        //LogData(`The ${tagsResp.Description} has an update available!`);
        if (tagsResp.Commands.length > 0) {
          await parseRMSCommands(tagsResp.Description, tagsResp.Commands);
        }
        break;
      case 1:
        LogData(`The ${tagsResp.Description} are up to date.`);
        break;
      case 2:
        LogData(`The ${tagsResp.Description} are up to date.`);
        break;
      default:
        LogData(`${tagsResp.Result} ${tagsResp.ResultCode}`);
        break;
    }
    return true;
  } catch (error) {
    return error;
  }
};

async function updateAllConfigs() {
  let bStatus = true;
  if (_DeviceConfigList != null) {
    bStatus = false;
    LogData(`Checking firmware specific configs...`);
    for (let index = 0; index < _DeviceConfigList.length; index++) {
      bStatus = await getDeviceInfo();
      bStatus = await updateConfig(_DeviceConfigList[index]);
    }

  }
  return bStatus;
}
async function updateConfig(configname) {
  try {
    let ver = null;
    let strVersion = mt_Utils.getDefaultValue("RMSVersion", "");
    strVersion.length > 0 ? ver = parseInt(strVersion) : ver = null;

    let req = {
      Authentication: null,
      ProfileName: mt_RMS_API.ProfileName,
      ConfigurationName: configname,
      TerminalConfiguration: null,
      BillingLabel: mt_Utils.getDefaultValue("RMSBillingLabel", "WEB Demo Test"),
      Version: ver,
      UIK: _UIK,
      MUT: _MUT,
      KSN: _KSN,
      InterfaceType: mt_Utils.getDefaultValue("RMSInterface", "USB"),
      DownloadPayload: true,
    };
    var configResp = await mt_RMS_API.GetConfig(req);


    switch (configResp.ResultCode) {
      case 0:
        //LogData(`The ${configResp.Description} has an update available!`);
        if (configResp.Commands.length > 0) {
          await parseRMSCommands(configResp.Description, configResp.Commands);
        }
        break;
      case 1:
        LogData(`The ${configResp.Description} is up to date.`);
        break;
      case 2:
        LogData(`The ${configResp.Description} is up to date.`);
        break;
      default:
        LogData(`${configResp.Result}`);
        break;
    }
    return true;
  }
  catch (error) {
    return error;
  }
};

async function updateFirmware(fwType) {
  try {
    _HasBLEFirmware = false;
    let fwid;
    switch (fwType.toLowerCase()) {
      case "ble":
        fwid = _BLEFWID;
        break;
      default:
        fwid = _FWID;
        break;
    }

    LogData(`Checking ${fwType} firmware...`);
    let req = {
      Authentication: null,
      ProfileName: mt_RMS_API.ProfileName,
      ConfigurationName: null,
      Version: null,
      UIK: _UIK,
      MUT: _MUT,
      KSN: _KSN,
      FirmwareID: fwid,
      InterfaceType: "USB",
      DownloadPayload: true,
    };

    var firmwareResp = await mt_RMS_API.GetFirmware(req);
    if (firmwareResp.HasBLEFirmware && fwType.toLowerCase() == "main") {
      _HasBLEFirmware = true;
      //LogData("This reader has BLE firmware");
    }
    if (firmwareResp.DeviceConfigs != null && fwType.toLowerCase() == "main") {
      _DeviceConfigList = firmwareResp.DeviceConfigs;
      //LogData("This reader has device configs");
    }

    switch (firmwareResp.ResultCode) {
      case 0:
        //LogData(`The ${fwType} firmware has an update available!`);
        if (firmwareResp.Commands.length > 0) {
          if (firmwareResp.ReleaseNotes.length > 0) LogData(firmwareResp.ReleaseNotes);
          if (firmwareResp.HasBLEFirmware && fwType.toLowerCase() == "main") {
            _HasBLEFirmware = true;
            LogData("This reader has BLE firmware");
          }
          if (firmwareResp.DeviceConfigs != null && fwType.toLowerCase() == "main") {
            _DeviceConfigList = firmwareResp.DeviceConfigs;
            LogData("This reader has device configs");
          }
          await parseRMSCommands(firmwareResp.Description, firmwareResp.Commands);
        }
        break;
      case 1:
        LogData(`The ${fwType} firmware is up to date.`);
        break;
      case 2:
        LogData(`The ${fwType} firmware is up to date.`);
        break;
      default:
        LogData(`${fwType} ${firmwareResp.Result}`);
        break;
    }
    return true;
  } catch (error) {
    return error;
  }
};
async function parseRMSCommand(message) {
  let Response;
  var cmd = message.split(",");
  switch (cmd[0].toUpperCase()) {
    case "GETDEVINFO":
      return mt_HID.getDeviceInfo();
      break;
    case "SENDCOMMAND":
      Response = await mt_mms.sendCommand(cmd[1]);
      return Response;
      break;
    case "SENDDATETIME":
      //Response = await mt_mms.sendCommand(mt_V5.calcDateTime());
      //return Response;
      break;
    case "SENDEXTENDEDCOMMAND":
      //Response = await mt_V5.sendExtendedCommand(cmd[1], cmd[2]);
      //return Response;
      break;
    case "SENDEXTCOMMAND":
      //Response = await mt_V5.sendExtCommand(cmd[1]);
      //return Response;
      break;
    case "GETDEVICELIST":
      devices = getDeviceList();
      break;
    case "OPENDEVICE":
      await mt_mms.openDevice();
      break;
    case "CLOSEDEVICE":
      await mt_mms.closeDevice();
      break;
    case "WAIT":
      _DeviceDetected = false;
      let numSecs = parseInt((cmd[1] / 1000), 10);
      let numQseconds = parseInt((numSecs * 4), 10)
      let index = 0
      while (index < numQseconds && !_DeviceDetected) {
        let progress = parseInt((index / numQseconds) * 100);
        await mt_Utils.wait(250);
        updateProgress(`Waiting up to ${numSecs} seconds...`, progress)
        index++
      }
      if (_DeviceDetected) {
        updateProgress(``, 100)
        await mt_Utils.wait(1000);
      }
      break;
    case "DETECTDEVICE":
      await mt_mms.closeDevice();
      await mt_mms.openDevice();
      await mt_Utils.wait(_openTimeDelay);
      if (window._device.opened) _DeviceDetected = true;
      break;
    case "APPENDLOG":
      break;
    case "DISPLAYMESSAGE":
      LogData(cmd[1]);
      break;
    case "GETTAGVALUE":
      let asAscii = (cmd[4] === 'true');
      var retval = mt_Utils.getTagValue(cmd[1], cmd[2], cmd[3], asAscii);
      LogData(`Get Tags for ${retval}`);
      break;
    case "PARSETLV":
      var retval = mt_Utils.tlvParser(mt_Utils.hexToBytes(cmd[1]));
      LogData("PARSETLV", JSON.stringify(retval));
      break;
    default:
      LogData(`Unknown Parse Command: ${cmd[0]}`);
  }
};

var mt_RMS = {
  _DeviceSN,
  _FWID,
  setDeviceDetected,
  setDeviceSN,
  setFWID,
  updateDevice
}
// import * as mt_RMS_API from "./mt_rms_api.js";
/* 
DO NOT REMOVE THIS COPYRIGHT
 Copyright 2020-2024 MagTek, Inc, Paul Deignan.
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), 
 to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

"use strict";
//import * as mt_V5 from "./mt_v5.js";
//import * as mt_Utils from "./mt_utils.js";


let BaseURL = "";
let APIKey = "";
let ProfileName = ""



/**
* @param {string} key
*/
function setAPIKey(key) {
  APIKey = key;
}

/**
 * @param {string} name
 */
function setProfileName(name) {
  ProfileName = name;
}

/**
 * @param {string} url
 */
function setURL(url) {
  BaseURL = url;
}

async function GetFirmware(request) {
  const url = BaseURL + "/Firmware";
  try {
    return await postRequest(url, APIKey, JSON.stringify(request));
  } catch (error) {
    throw error;
  }
}

async function GetTags(request) {
  const url = BaseURL + "/tags";
  try {
    return await postRequest(url, APIKey, JSON.stringify(request));
  } catch (error) {
    throw error;
  }
}

async function GetConfig(request) {
  const url = BaseURL + "/configs";
  try {
    return await postRequest(url, APIKey, JSON.stringify(request));
  } catch (error) {
    throw error;
  }
}

async function postRequest(url, apiKey, data) {
  try {
    const response = await fetch(url, {
      method: "POST",
      body: data,
      mode: "cors",
      headers: new Headers({
        "Content-Type": "application/json",
        APIKey: apiKey,
      }),
    });
    return await response.json();
  } catch (error) {
    return error;
  }
}

var mt_RMS_API = {
  BaseURL,
  APIKey,
  ProfileName,
  setAPIKey,
  setProfileName,
  setURL,
  GetFirmware,
  GetTags,
  GetConfig
}
// import "./mt_events.js";

// Expose EventEmitter globally so it can be used in the webpage
window.EventEmitter = EventEmitter;

let defaultRMSURL = '';
let defaultRMSAPIKey = '';
let defaultRMSProfileName = '';


let _contactSeated = false;
let _AwaitingContactEMV = false;
let _contactlessDelay = parseInt(mt_Utils.getDefaultValue("ContactlessDelay", "500"));

async function handleDOMLoaded() {
  let devices = await mt_HID.getDeviceList();
  mt_UI.LogData(`Devices currently attached and allowed:`);

  if (devices.length == 0) mt_UI.setUSBConnected("Connect a device");
  devices.forEach((device) => {
    mt_UI.LogData(`${device.productName}`);
    mt_UI.setUSBConnected("Connected");
  });



  //Add the hid event listener for connect/plug in
  navigator.hid.addEventListener("connect", async ({ device }) => {
    EmitObject({ Name: "OnDeviceConnect", Device: device });
    if (mt_MMS.wasOpened) {
      await mt_Utils.wait(_openTimeDelay);
      await handleOpenButton();
    }
  });

  //Add the hid event listener for disconnect/unplug
  navigator.hid.addEventListener("disconnect", ({ device }) => {
    EmitObject({ Name: "OnDeviceDisconnect", Device: device });
  });
}

async function handleCloseButton() {
  mt_MMS.closeDevice();
  mt_UI.ClearLog();
  mt_UI.DeviceDisplay("");
}
async function handleClearButton() {
  mt_UI.ClearLog();
  mt_UI.DeviceDisplay("");
  document.getElementById("fileInput").value = null;
}

async function handleOpenButton() {
  window._device = await mt_MMS.openDevice();
}

async function handleSendCommandButton() {
  const data = document.getElementById("sendData");
  await parseCommand(data.value);
}


document.addEventListener("DOMContentLoaded", function () {
  document
    .querySelector("#deviceOpen")
    .addEventListener("click", handleOpenButton);
  document
    .querySelector("#deviceClose")
    .addEventListener("click", handleCloseButton);
  document
    .querySelector("#sendCommand")
    .addEventListener("click", handleSendCommandButton);
  document
    .querySelector("#clearCommand")
    .addEventListener("click", handleClearButton);
  document
    .querySelector("#CommandList")
    .addEventListener("change", mt_UI.FromListToText);
  document.addEventListener("DOMContentLoaded", handleDOMLoaded);

  document.getElementById('fileInput')
    .addEventListener('change', handleFileUpload);
});

function EmitObject(e_obj) {
  EventEmitter.emit(e_obj.Name, e_obj);
};

async function parseCommand(message) {
  let Response;
  let cmd = message.split(",");
  switch (cmd[0].toUpperCase()) {
    case "GETAPPVERSION":
      mt_Utils.debugLog("GETAPPVERSION " + appOptions.version);
      break;
    case "GETDEVINFO":
      mt_Utils.debugLog("GETDEVINFO " + getDeviceInfo());
      break;
    case "SENDCOMMAND":
      Response = await mt_MMS.sendCommand(cmd[1]);
      mt_UI.LogData(Response.HexString)
      break;
    case "PCIRESET":
      Response = await mt_MMS.sendCommand("AA00810401121F0184021F01");
      break;
    case "GETDEVICELIST":
      devices = getDeviceList();
      break;
    case "OPENDEVICE":
      window._device = await mt_MMS.openDevice();
      break;
    case "CLOSEDEVICE":
      await mt_MMS.closeDevice();
      break;
    case "WAIT":
      mt_UI.LogData(`Waiting ${cmd[1] / 1000} seconds...`);
      await mt_Utils.wait(cmd[1]);
      //mt_UI.LogData(`Done Waiting`);
      break;
    case "DETECTDEVICE":
      window._device = await mt_MMS.openDevice();
      break;
    case "GETTAGVALUE":
      let asAscii = (cmd[4] === 'true');
      var retval = mt_Utils.getTagValue(cmd[1], cmd[2], cmd[3], asAscii);
      mt_UI.LogData(retval);
      break;
    case "PARSETLV":
      var retval = mt_Utils.tlvParser(cmd[1]);
      mt_UI.LogData(JSON.stringify(retval));
      break;
    case "DISPLAYMESSAGE":
      mt_UI.LogData(cmd[1]);
      break;
    case "GETDEVICESN":
      var sn = await mt_MMS.GetDeviceSN();
      mt_UI.LogData(sn);
      break;
    case "GETFIRMWAREID":
      var fw = await mt_MMS.GetDeviceFWID();
      mt_UI.LogData(fw);
      break;
    case "UPDATEDEVICE":
      mt_RMS_API.setURL(mt_Utils.getDefaultValue('baseURL', defaultRMSURL));
      mt_RMS_API.setAPIKey(mt_Utils.getDefaultValue('APIKey', defaultRMSAPIKey));
      mt_RMS_API.setProfileName(mt_Utils.getDefaultValue('ProfileName', defaultRMSProfileName));
      fw = await mt_MMS.GetDeviceFWID();
      sn = await mt_MMS.GetDeviceSN();

      mt_RMS.setFWID(fw);
      mt_RMS.setDeviceSN(sn);

      if (mt_RMS_API.BaseURL.length > 0 && mt_RMS_API.APIKey.length > 0 && mt_RMS_API.ProfileName.length > 0) {
        await mt_RMS.updateDevice();
      } else {
        mt_UI.LogData(`Please set APIKey and ProfileName`);
      }
      break;
    default:
      mt_Utils.debugLog("Unknown Command");
  }
};

function ClearAutoCheck() {
  var chk = document.getElementById("chk-AutoStart");
  chk.checked = false;
}

const deviceConnectLogger = (e) => {
  mt_UI.setUSBConnected("Connected");
};
const deviceDisconnectLogger = (e) => {
  mt_UI.setUSBConnected("Disconnected");
};
const deviceCloseLogger = (e) => {
  mt_UI.setUSBConnected("Closed");
};
const deviceOpenLogger = (e) => {
  mt_UI.setUSBConnected("Opened");
};
const dataLogger = (e) => {
  mt_UI.LogData(`Received Data: ${e.Name}: ${e.Data}`);
};

const NFCUIDLogger = (e) => {
  mt_UI.LogData(`Received NFC UID : ${e.Name}: ${e.Data}`);
  mt_MMS.sendCommand("AA00810401641100840B1100810160820100830100");
  mt_MMS.sendCommand("AA00810401671100840D110081033A04278201008301FF");

};


const PINLogger = (e) => {
  mt_UI.LogData(`${e.Name}: EPB:${e.Data.EPB} KSN:${e.Data.KSN} Encryption Type:${e.Data.EncType} PIN Block Format: ${e.Data.PBF} TLV: ${e.Data.TLV}`);

  let TLVs = mt_Utils.tlvParser(e.Data.TLV.substring(24));
  mt_UI.LogData("TLVs---------------------------------");
  TLVs.forEach(element => {
    mt_UI.LogData(`${element.tag} : ${element.tagValue} `);
  });
  mt_UI.LogData("TLVs---------------------------------");

};

const trxCompleteLogger = (e) => {
  mt_UI.LogData(`${e.Name}: ${e.Data}`);
};
const displayMessageLogger = (e) => {
  mt_UI.LogData(`Display: ${e.Data}`);
  mt_UI.DeviceDisplay(e.Data);
};
const barcodeLogger = (e) => {
  //mt_UI.LogData(`Barcode  Data: ${e.Data}`);
  mt_UI.LogData(`Barcode  Data: ${mt_Utils.getTagValue("DF74", "", e.Data, true)}`);
};
const arqcLogger = (e) => {
  mt_UI.LogData(`${e.Source} ARQC Data:  ${e.Data}`);
  let TLVs = mt_Utils.tlvParser(e.Data.substring(4));
  mt_UI.LogData("TLVs---------------------------------");
  TLVs.forEach(element => {
    mt_UI.LogData(`${element.tag} : ${element.tagValue} `);
  });
  mt_UI.LogData("TLVs---------------------------------");
};
const batchLogger = (e) => {
  mt_UI.LogData(`${e.Source} Batch Data: ${e.Data}`);
};
const fromDeviceLogger = (e) => {
  //mt_UI.LogData(`Device Response: ${e.Data.HexString}`);
};
const inputReportLogger = (e) => {
  mt_UI.LogData(`Input Report: ${e.Data}`);
};
const errorLogger = (e) => {
  mt_UI.LogData(`Error: ${e.Source} ${e.Data}`);
};
const debugLogger = (e) => {
  mt_UI.LogData(`Error: ${e.Source} ${e.Data}`);
};
const touchUpLogger = (e) => {
  var chk = document.getElementById("chk-AutoTouch");
  if (chk.checked) {
    mt_UI.LogData(`Touch Up: X: ${e.Data.Xpos} Y: ${e.Data.Ypos}`);
  }
};

const touchDownLogger = (e) => {
  var chk = document.getElementById("chk-AutoTouch");
  if (chk.checked) {
    mt_UI.LogData(`Touch Down: X: ${e.Data.Xpos} Y: ${e.Data.Ypos}`);
  }
};

const contactlessCardDetectedLogger = async (e) => {
  if (e.Data.toLowerCase() == "idle") mt_UI.LogData(`Contactless Card Detected`);
  var chk = document.getElementById("chk-AutoNFC");
  var chkEMV = document.getElementById("chk-AutoEMV");
  var _autoStart = document.getElementById("chk-AutoStart");
  if (_autoStart.checked & chk.checked & (e.Data.toLowerCase() == "idle")) {
    ClearAutoCheck();
    mt_UI.LogData(`Auto Starting...`);
    if (chkEMV.checked) {
      _AwaitingContactEMV = true;
      mt_UI.LogData(`Delaying Contactless ${_contactlessDelay}ms`);
      await mt_Utils.wait(_contactlessDelay);
    }
    if (!_contactSeated) {
      _AwaitingContactEMV = false;
      // We didn't get a contact seated, do start the contactless transaction
      //mt_MMS.sendCommand("AA008104010010018430100182010AA30981010082010083010184020003861A9C01009F02060000000001009F03060000000000005F2A020840");      
      mt_MMS.sendCommand("AA00810401031001843D1001820178A3098101008201008301038402020386279C01009F02060000000001009F03060000000000005F2A0208405F3601029F150200009F530100");
    }
  }
};

const contactlessCardRemovedLogger = (e) => {
  if (e.Data.toLowerCase() == "idle") mt_UI.LogData(`Contactless Card Removed`);
};

const contactCardInsertedLogger = (e) => {
  _contactSeated = true;
  if (e.Data.toLowerCase() == "idle") mt_UI.LogData(`Contact Card Inserted`);
  var chk = document.getElementById("chk-AutoEMV");
  var _autoStart = document.getElementById("chk-AutoStart");
  if (
    _autoStart.checked & chk.checked & (e.Data.toLowerCase() == "idle") ||
    _AwaitingContactEMV
  ) {
    _AwaitingContactEMV = false;
    ClearAutoCheck();
    mt_UI.LogData(`Auto Starting EMV...`);
    mt_MMS.sendCommand(
      "AA008104010010018430100182010AA30981010082010183010084020003861A9C01009F02060000000001009F03060000000000005F2A020840"
    );
  }
};

const contactCardRemovedLogger = (e) => {
  _contactSeated = false;
  if (e.Data.toLowerCase() == "idle") mt_UI.LogData(`Contact Card Removed`);
};

const msrSwipeDetectedLogger = (e) => {
  if (e.Data.toLowerCase() == "idle") mt_UI.LogData(`MSR Swipe Detected ${e.Data}`);
  var chk = document.getElementById("chk-AutoMSR");
  var _autoStart = document.getElementById("chk-AutoStart");
  if (_autoStart.checked & chk.checked & (e.Data.toLowerCase() == "idle")) {
    ClearAutoCheck();
    mt_UI.LogData(`Auto Starting MSR...`);
    mt_MMS.sendCommand(
      "AA008104010010018430100182010AA30981010182010183010084020003861A9C01009F02060000000001009F03060000000000005F2A020840"
    );
  }
};

const userEventLogger = (e) => {
  mt_UI.LogData(`User Event Data: ${e.Name} ${e.Data}`);
};

const fileLogger = (e) => {
  //mt_UI.LogData(`File: ${e.Data.HexString}`);
};


async function handleFileUpload(event) {
  if (event.target.files.length == 1) {
    const file = event.target.files[0];

    const reader = new FileReader();

    reader.onload = async function (e) {
      const lines = e.target.result.split('\n');
      for (const line of lines) {
        // Process each line here
        await parseCommand(line);

      }
    };
    reader.readAsText(file);
  };
}


const displayRMSLogger = (e) => {
  mt_UI.LogData(`RMS Display: ${e.Data}`);
};

const displayRMSProgressLogger = (e) => {
  mt_UI.updateProgressBar(e.Data.Caption, e.Data.Progress)
};

const displayFirmwareLoadStatusLogger = (e) => {
  mt_UI.LogData(`RMS Firmware Load Status: ${e.Data}`);
};



// Subscribe to  events
EventEmitter.on("OnInputReport", inputReportLogger);
EventEmitter.on("OnDeviceConnect", deviceConnectLogger);
EventEmitter.on("OnDeviceDisconnect", deviceDisconnectLogger);

EventEmitter.on("OnDeviceOpen", deviceOpenLogger);
EventEmitter.on("OnDeviceClose", deviceCloseLogger);

EventEmitter.on("OnBarcodeDetected", barcodeLogger);
EventEmitter.on("OnBarcodeRead", dataLogger);
EventEmitter.on("OnBarcodeUpdate", dataLogger);

EventEmitter.on("OnARQCData", arqcLogger);
EventEmitter.on("OnBatchData", batchLogger);

EventEmitter.on("OnContactCardDetected", dataLogger);
EventEmitter.on("OnContactPINBlockError", dataLogger);
EventEmitter.on("OnContactPINPadError", dataLogger);

EventEmitter.on("OnContactlessCardCollision", dataLogger);
EventEmitter.on("OnContactlessMifare1KCardDetected", dataLogger);
EventEmitter.on("OnContactlessMifare4KCardDetected", dataLogger);
EventEmitter.on("OnContactlessMifareUltralightCardDetected", dataLogger);
EventEmitter.on("OnContactlessNFCUID", NFCUIDLogger);
EventEmitter.on("OnContactlessPINBlockError", dataLogger);
EventEmitter.on("OnContactlessPINPadError", dataLogger);
EventEmitter.on("OnContactlessVASError", dataLogger);

EventEmitter.on("OnFirmwareUpdateFailed", dataLogger);
EventEmitter.on("OnFirmwareUpdateSuccessful", dataLogger);
EventEmitter.on("OnFirmwareUptoDate", dataLogger);

EventEmitter.on("OnManualDataEntered", dataLogger);

EventEmitter.on("OnMSRCardDetected", dataLogger);
EventEmitter.on("OnMSRCardInserted", dataLogger);
EventEmitter.on("OnMSRCardRemoved", dataLogger);
EventEmitter.on("OnMSRCardSwiped", dataLogger);

EventEmitter.on("OnPowerEvent", dataLogger);

EventEmitter.on("OnTransactionComplete", trxCompleteLogger);
EventEmitter.on("OnTransactionHostAction", dataLogger);

EventEmitter.on("OnUIHostActionComplete", dataLogger);
EventEmitter.on("OnUIHostActionRequest", dataLogger);
EventEmitter.on("OnUIInformationUpdate", dataLogger);

EventEmitter.on("OnUserEvent", userEventLogger);

EventEmitter.on("OnContactlessCardDetected", contactlessCardDetectedLogger);
EventEmitter.on("OnContactlessCardRemoved", contactlessCardRemovedLogger);
EventEmitter.on("OnContactCardInserted", contactCardInsertedLogger);
EventEmitter.on("OnContactCardRemoved", contactCardRemovedLogger);
EventEmitter.on("OnMSRSwipeDetected", msrSwipeDetectedLogger);

EventEmitter.on("OnDeviceResponse", fromDeviceLogger);
EventEmitter.on("OnTouchDown", touchDownLogger);
EventEmitter.on("OnTouchUp", touchUpLogger);

EventEmitter.on("OnError", errorLogger);
EventEmitter.on("OnPINComplete", PINLogger);
EventEmitter.on("OnUIDisplayMessage", displayMessageLogger);
EventEmitter.on("OnDebug", debugLogger);

EventEmitter.on("OnFileFromHost", fileLogger);
EventEmitter.on("OnFileFromDevice", fileLogger);

EventEmitter.on("OnRMSLogData", displayRMSLogger);
EventEmitter.on("OnRMSProgress", displayRMSProgressLogger);
EventEmitter.on("OnFirmwareLoadStatus", displayFirmwareLoadStatusLogger);
